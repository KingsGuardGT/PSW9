<!-- DAFTAR MENU -->

<?php 
	include "connect.php";
	include "include/functions/functions.php";
    include "include/template/header.php";
    include "include/template/navbar.php";
	
	// membuat website setting

	$stmt_web_settings = $con->prepare("SELECT * FROM website_settings");
    $stmt_web_settings->execute();
    $web_settings = $stmt_web_settings->fetchAll();

    $nama_restaurant = "";
    $email_restaurant = "";
    $alamat_restaurant = "";
    $notelp_restaurant = "";

    foreach ($web_settings as $option)
    {
        if($option['option_name'] == 'nama_restaurant')
        {
            $nama_restaurant = $option['option_value'];
        }

        elseif($option['option_name'] == 'email_restaurant')
        {
            $email_restaurant = $option['option_value'];
        }

        elseif($option['option_name'] == 'notelp_restaurant')
        {
            $notelp_restaurantrestaurant = $option['option_value'];
        }
        elseif($option['option_name'] == 'alamat_restaurant')
        {
            $alamat_restaurantrestaurant = $option['option_value'];
        }
    }

?>


	<section class="our_menus" id="produk">
		<div class="container">
			<h2 style="text-align: center;margin-bottom: 30px">DISCOVER OUR MENUS</h2>
			<div class="menus_tabs">
				<div class="menus_tabs_picker">
					<ul style="text-align: center;margin-bottom: 70px">
						<?php

	                        $stmt = $con->prepare("Select * from produk_kategori");
	                        $stmt->execute();
	                        $rows = $stmt->fetchAll();
	                        $count = $stmt->rowCount();

	                        $x = 0;

	                        foreach($rows as $row)
	                        {
	                        	if($x == 0)
	                        	{
	                        		echo "<li class = 'menu_category_name tab_category_links active_category' onclick=showCategoryMenus(event,'".str_replace(' ', '', $row['nama_kategori'])."')>";
	                        			echo $row['nama_kategori'];
	                        		echo "</li>";

	                        	}
	                        	else
	                        	{
	                        		echo "<li class = 'menu_category_name tab_category_links' onclick=showCategoryMenus(event,'".str_replace(' ', '', $row['nama_kategori'])."')>";
	                        			echo $row['nama_kategori'];
	                        		echo "</li>";
	                        	}

	                        	$x++;
	                     		
	                        }
						?>
					</ul>
				</div>

				<div class="menus_tab">
					<?php
                
                        $stmt = $con->prepare("Select * from produk_kategori");
                        $stmt->execute();
                        $rows = $stmt->fetchAll();
                        $count = $stmt->rowCount();

                        $i = 0;

                        foreach($rows as $row) 
                        {

                            if($i == 0)
                            {

                                echo '<div class="menu_item  tab_category_content" id="'.str_replace(' ', '', $row['nama_kategori']).'" style=display:block>';

                                    $stmt_produk = $con->prepare("Select * from produk where id_kategori = ?");
                                    $stmt_produk->execute(array($row['id_kategori']));
                                    $rows_produk = $stmt_produk->fetchAll();

                                    if($stmt_produk->rowCount() == 0)
                                    {
                                        echo "<div style='margin:auto'>No Available Menus for this category!</div>";
                                    }

                                    echo "<div class='row'>";
	                                    foreach($rows_produk as $produk)
	                                    {
	                                        ?>

	                                            <div class="col-md-4 col-lg-3 menu-column">
	                                                <div class="thumbnail" style="cursor:pointer">
	                                                    <?php $source = "images/icon/".$produk['gambar_produk']; ?>

	                                                    <div class="menu-image">
													        <div class="image-preview">
													            <div style="background-image: url('<?php echo $source; ?>');"></div>
													        </div>
													    </div>
														                                                    
	                                                    <div class="caption">
	                                                        <h5>
	                                                            <?php echo $produk['nama_produk'];?>
	                                                        </h5>
	                                                        <p>
	                                                            <?php echo $produk['jenis_produk']; ?>
	                                                        </p>
	                                                        <span class="menu_price">
	                                                        	<?php echo "Rp".$produk['harga_produk']; ?>
	                                                        </span>
	                                                    </div>
	                                                </div>
	                                            </div>

	                                        <?php
	                                    }
	                                echo "</div>";

                                echo '</div>';

                            }

                            else
                            {

                                echo '<div class="produk_kategori  tab_category_content" id="'.str_replace(' ', '', $row['id_kategori']).'">';

                                    $stmt_produk = $con->prepare("Select * from produk where id_kategori = ?");
                                    $stmt_produk->execute(array($row['id_kategori']));
                                    $rows_produk = $stmt_produk->fetchAll();

                                    if($stmt_produk->rowCount() == 0)
                                    {
                                        echo "<div class = 'no_menus_div'>No Available Menus for this category!</div>";
                                    }

                                    echo "<div class='row'>";
	                                    foreach($rows_produk as $produk)
	                                    {
	                                        ?>

	                                            <div class="col-md-4 col-lg-3 menu-column">
	                                                <div class="thumbnail" style="cursor:pointer">
	                                                	<?php $source = "images/icon/".$menu['gambar_produk']; ?>
	                                                    <div class="menu-image">
													        <div class="image-preview">
													            <div style="background-image: url('<?php echo $source; ?>');"></div>
													        </div>
													    </div>
	                                                    <div class="caption">
	                                                        <h5>
	                                                            <?php echo $produk['nama_produk'];?>
	                                                        </h5>
	                                                        <p>
	                                                            <?php echo $produk['jenis_produk']; ?>
	                                                        </p>
	                                                        <span class="harga_produk">
	                                                        	<?php echo "Rp".$produk['harga_produk']; ?>
	                                                        </span>
	                                                    </div>
	                                                </div>
	                                            </div>

	                                        <?php
	                                    }
	                               	echo "</div>";

                                echo '</div>';

                            }

                            $i++;
                            
                        }
                    
                        echo "</div>";
                
                    ?>
				</div>
			</div>
		</div>
	</section>
