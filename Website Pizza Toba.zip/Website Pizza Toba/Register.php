<?php

require_once("config.php");

if(isset($_POST['register'])){

    // filter data yang diinputkan
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    // enkripsi password
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);


    // menyiapkan query
    $sql = "INSERT INTO users (name, username, email, password) 
            VALUES (:name, :username, :email, :password)";
    $stmt = $db->prepare($sql);

    // bind parameter ke query
    $params = array(
        ":name" => $name,
        ":username" => $username,
        ":password" => $password,
        ":email" => $email
    );

    // eksekusi query untuk menyimpan ke database
    $saved = $stmt->execute($params);

    // jika query simpan berhasil, maka user sudah terdaftar
    // maka alihkan ke halaman login
    if($saved) header("Location: login.php");
}

?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="UTF-8">
        <title>Halaman Register</title>
        <link rel="stylesheet" href="Register-style.css">
    </head>
    <body>
        <div class="A1">
            <h1>Register Here</h1>
            <form method="post" action="Starting Homepage.php">
                <div class="text_field">
                    <input type="text" required>
                    <span></span>
                    <label>Username</label>
                </div>
                <div class="text_field">
                    <input type="text" required>
                    <span></span>
                    <label>Name</label>
                </div>
                <div class="text_field">
                    <input type="password" required>
                    <span></span>
                    <label>Password</label>
                </div>
                <div class="text_field">
                    <input type="text" required>
                    <span></span>
                    <label>E-Mail</label>
                </div>
                <input type="submit" value="Register Now" href="Login.php">
                <div class="signup_link">
            </form>
        </div>
    </body>
</html>