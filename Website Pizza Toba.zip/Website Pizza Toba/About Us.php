<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>About Us</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <style>
            h6 {
                color: white;
            }
            h1 {
                color: #FFCC00;
                font-family: Inkut Antiqua;
            }
            footer{
                background-image: url("img/bg2.jpeg");
                width: auto;
                height: 786px;
                background-repeat: no-repeat;
            }
            p{
                color: white;
                font-size: x-large;
            }
            h5 {
                color: #FFCC00;
                font-family: Inknut Antiqua;
                font-size: xx-large;
            }
            .atas {
                background-image: url("img/bg1.jpeg");
                width: auto;
                height: 500px;
                background-attachment: fixed;
                background-repeat: no-repeat;
            }
            .inti {
                background-color: #383131;
                width: auto;
            }
            .judul{
                font-family: Just Me Again Down Here;
                color: #FFCC00;
            }
            li{
                list-style: none;
                color: white;
            }
            li a{
                color: white;
            }

            li a:hover{
                color:white;
                list-style: none;
                text-decoration: none;
            }

            nav ul li{
                float: right;
                text-align: right;
                margin-right: 100px;
                text-decoration: none;
            }
            nav ul li:hover{
                color: white;
                text-decoration: none;
            }
            .orang {
                border-radius: 1000%
            }
        </style>
    </head>
    <body>
        <header class="inti"> 
            <nav>
                <ul>
                    <li>
                        <a href="About Us.php">About Us </a>
                    </li>
                    <li>
                        <a href="Menu.php">Menu</a>
                    </li>
                    <li>
                        <a href="Starting Homepage.php">Home</a>
                    </li>
                    <img src="img/pizza.jpeg" width="50px" height="50px" style="margin-left: 50px;">
                </ul>
                <div class="atas">
                    <div class="judul">
                        <center><h1>ABOUT &nbsp US</h1></center>
                    </div>
                    <div class="isi">
                        <h5>What we do??</h5><br><br>
                        <p>We created this website just for you,</h6> </p><br><br>
                        <p>who love pizza culinary, so you can quickly try </p><br><br>
                        <p>new and unique flavors</p>
                    </div>
                </div>
            </nav>
        </header>
        <footer>
            <center><h1>Our Team</h1></center><br><br><br><br><br><br><br><br>
            <center><img class="orang" src="img/yudi.jpeg" width="100px" height="100px"></center>
                <center> <b><h6>Yudi Saragih<br>
                    (Product Mananger)
                </b></h6></center><br><br><br><br><br><br><br><br><br><br>
            <section class="call-to-action">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <span class="glyphicon glyphicon-star glyphiconlarge" ariahidden="true"></span>
                            <img src="img/kristopeles.jpeg" class="orang" width="100px" height="100px">
                            <br><h6><b>Kristopeles H Tambunan 
                                <br>(Analyst)
                            </b></h6>
                        </div>
                        <div class="col-md-3">
                            <span class="glyphicon glyphicon-star glyphiconlarge" ariahidden="true"></span>
                            <img src="img/aldline.jpeg" class="orang" width="100px" height="100px">
                            <br><h6><b>Aldline Sihombing  
                                <br>(Database Designer)
                            </b></h6>
                        </div>
                        <div class="col-md-3">
                            <span class="glyphicon glyphicon-star glyphiconlarge" ariahidden="true"></span>
                            <img src="img/yuni.jpeg" class="orang" width="100px" height="100px">
                            <br><h6><b>Yuni Y Siagian
                                <br>(Database Designer)
                            </h6></b>
                        </div>
                        <div class="col-md-3">
                            <span class="glyphicon glyphicon-star glyphiconlarge" ariahidden="true"></span>
                            <img src="img/samuel.jpeg" class="orang" width="100px" height="100px">
                            <br><h6><b>Samuel E Simangunsong
                                <br>(Database Designer)
                            </b></h6>
                        </div>
                    </div>
                </div>
            </section>
        </footer>
    </body>
</html>