<?php 

require_once("config.php");

if(isset($_POST['login'])){

    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

    $sql = "SELECT * FROM users WHERE username=:username OR email=:email";
    $stmt = $db->prepare($sql);
    
    $params = array(
        ":username" => $username,
        ":email" => $username
    );

    $stmt->execute($params);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($user){
        if(password_verify($password, $user["password"])){
            session_start();
            $_SESSION["user"] = $user;
            header("Location: Home.php");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="UTF-8">
        <title>Halaman Log In</title>
        <link rel="stylesheet" href="Login-style.css">
    </head>
    <body>
        <div class="A1">
            <h1>Log In</h1>
            <form method="post" action="Starting Homepage.php">
                <div class="text_field">
                    <input type="text" required>
                    <span></span>
                    <label>Username</label>
                </div>
                <div class="text_field">
                    <input type="password" required>
                    <span></span>
                    <label>Password</label>
                </div>
                <div class="pass">Forgot Password</div>
                <input type="submit" value="Login" href="Login.php">
                <div class="signup_link">
                    Didn't have an account yet ?? <br><br> <a href="Register.php">Register here</a></div>
            </form>
        </div>
    </body>
</html>