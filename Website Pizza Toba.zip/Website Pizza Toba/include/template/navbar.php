<!-- Membuat Navbar-->

<header id="header" class="header-section">
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="navbar-brand">
                    <img src="images/background/logo.png" alt="Logo Pizza Toba" style="width: 150px;">
                </a>
                <div class="d-flex menu-wrap align-items-center">
                    <div class="mainmenu" id="mainmenu">
                        <ul class="nav">
                            <li><a href="Starting Homepage.php">HOME</a></li>
                            <li><a href="menu.php">MENUS</a></li>
                            <li><a href="About Us.php">ABOUT US</a></li>
                        </ul>
                    </div>
                    </div>
                </div>
            </nav>
        </div>
    </header>

	<div class="header-height" style="height: 120px;"></div>
