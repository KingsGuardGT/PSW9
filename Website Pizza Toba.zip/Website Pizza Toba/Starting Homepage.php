<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Pizza Toba Website</title>
    <link rel="stylesheet" href="Home-style.css">
    <link rel="stylesheet" href="customized.bootstrap.min.css">
  </head>
  <body>
    <section>
      <header class="heads">
        <ul>
        <a href="Starting Homepage.php"><img src=images/Logo-removebg-preview.png alt="HTML tutorial" style="width:130px;height:130px;"></a>
          <li><a href="Starting Homepage.php">Home</a></li>
          <li><a href="Menu.php">Menu</a></li>
          <li><a href="About Us.php">About Us</a></li>
        </ul>
      </header>
      <div class="content">
        <div class="textBox">
          <h2>Pizza Toba</h2>
          <p>A Slice of<span>  Love from Toba</span><br>Just<span> For You</span></p><br>
          <a href="Menu.php">Show Me Your Menu</a>
        </div>
      </div>
    </section>
    <div class="our_qualities" style="padding:100px 0px;">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <div class="our_qualities_column">
                        <img src="images/quality_food_img.png" >
                        <div class="caption">
                            <h3>
                              Fresh Ingredients
                            </h3>
                            <p>
                              We prepare every fresh and quality food ingredient, for the quality of each menu that we 
                            </p>
                        </div>
                    </div>
          </div>
          <div class="col-md-4">
            <div class="our_qualities_column">
                        <img src="images/original_taste_img.png" >
                        <div class="caption">
                            <h3>
                                New & Unique Taste
                            </h3>
                            <p>
                              For those who like pizza culinary, we serve a new and truly unique taste.
                            </p>
                        </div>
                    </div>
          </div>
          <div class="col-md-4">
            <div class="our_qualities_column">
                        <img src="images/fast_delivery_img.png" >
                        <div class="caption">
                            <h3>
                                Fast Delivery
                            </h3>
                            <p>
                              We make sure every order we receive, gets into the customer's hands quickly and on time
                            </p>
                        </div>
                    </div>
          </div>
  
        </div>
      </div>
    </div>
  </body>
</html>