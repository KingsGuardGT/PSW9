<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Pizza Toba Website</title>
    <link rel="stylesheet" href="Landing-style.css">
  </head>
  <body>
    <section>
      <div class="content">
        <div class="textBox">
            <h1 class="welcome">Welcome</h1> <br>
            <h1 class="attributes">To</h1>
            <br>
            <h2>Pizza Toba</h2>
            <br>
            <br>
            <a href="Login.php"class="button">MASUK</a>
            <br>
            <br>
            <p>Didn't have account yet ??</p>
            <a href="Register.php" class="hyperlink">Register Now</a>
        </div>
      </div>
    </section>
  </body>
</html>